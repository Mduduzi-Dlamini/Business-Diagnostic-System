<?php
include('header.php');

if (isset($_POST['add'])) {
  $requirements = $_POST['requirements'];
  $sql="INSERT INTO Human_Resource(hr_id, Requirements) VALUES (NULL,'$requirements');";
  mysqli_query($conn, $sql);
  echo "<script>alert(\"Successfully Added...!\")</script>";
}
if (isset($_POST['update'])) {
  $id = $_POST['id'];
  $requirements=$_POST['Requirements'];
  $description = $_POST['Description'];
  $progress = $_POST['Progress'];
  $date = $_POST['Date'];
  $version = $_POST['Version'];
  $sql = "UPDATE Human_Resource SET Requirements='$requirements',Descriptions='$description',Progress='$progress',Due_date='$date',Versions='$version' WHERE hr_id='$id';";
  mysqli_query($conn, $sql);
  echo "<script>alert(\"Successfully Added...!\")</script>";
}




?>
      <!-- Sidebar Navigation end-->
      <div class="page-content">
        <!-- Page Header-->
        <div class="page-header no-margin-bottom">
          <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">Human Resource Officer</h2>
          </div>
        </div>
        <!-- Breadcrumb-->
        <div class="container-fluid">
          <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item active">Human Resource Officer</li>
          </ul>
        </div>
        <section class="no-padding-top">
          <div class="container-fluid">
            <div class="row">
        
              <!-- Modal Form-->
              <div class="col-lg-6">
                <div class="block">
                  <div class="title"><strong>Add Business Examination</strong></div>
                  <div class="block-body text-center">
                    <button type="button" data-toggle="modal" data-target="#myModal" class="btn btn-primary">Add </button>
                    <!-- Modal-->
                    <div id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
                      <div role="document" class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header"><strong id="exampleModalLabel" class="modal-title">Business Examination</strong>
                            <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
                          </div>
                          <div class="modal-body">
                            <p>Add Any Human Resource Business Aspect.</p>
                            <form action="hr_diagnosis.php" method="post">
                              <div class="form-group">
                                <label>Requirements</label>
                                <input type="text" name="requirements" placeholder="Requirements" class="form-control">
                              </div>
                          </div>
                          <div class="modal-footer">
                            <button type="button" data-dismiss="modal" class="btn btn-secondary">Close</button>
                            <button type="submit" name ="add"class="btn btn-primary">Save changes</button>
                          </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-12">
                <div class="block">
                  <div class="title"><strong>Striped table with hover effect</strong></div>
                  <div class="table-responsive"> 
                    <table class="table table-striped table-hover">
                      <thead>
                        <tr>
                          <th>Requirements</th>
                          <th>Description</th>
                          <th>Progress</th>
                          <th>Due Date</th>
                          <th>Version</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php
                        $sql = "SELECT * FROM Human_Resource;";
                        $result = mysqli_query($conn, $sql);
                        $resultcheck = mysqli_num_rows($result);
                                  
                        if($resultcheck>0) {
                            while($row = mysqli_fetch_assoc($result)) {
                                echo '
                                <tr>
                                    
                                    <td>'.$row['Requirements'].'</td>
                                    <td>'.$row['Descriptions'].'</td>
                                    <td>'.$row['Progress'].'</td>
                                    <td>'.$row['Due_date'].'</td>
                                    <td>'.$row['Versions'].'</td>
                                    <td><button type="button" data-toggle="modal" data-target="#myModal'.$row['hr_id'].'" class="btn btn-info">Edit</button></td>
                                    <td><button type="submit" name="add" class="btn btn-danger">Remove</button></td>
                                </tr>
                                
                                
                                ';?>
                                <div id="myModal<?php echo $row['hr_id']?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
                                  <div role="document" class="modal-dialog">
                                  <div class="modal-content">
                                    <div class="modal-header"><strong id="exampleModalLabel" class="modal-title">Business Examination</strong>
                                      <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
                                    </div>
                                    <div class="modal-body">
                                      <p>Add Any Human Resource Business Aspect.</p>
                                      <form action="hr_diagnosis.php" method="post">
                                        <input type="hidden"name="id" value="<?php echo $row['hr_id']?>">
                                        <div class="form-group">
                                          <label>Requirements</label>
                                          <input type="text" name="Requirements" value="<?php echo $row['Requirements']?>" placeholder="Requirements" class="form-control" required>
                                        </div>
                                        <div class="form-group">
                                          <label>Description</label>
                                          <input type="text" name="Description" value="<?php echo $row['Descriptions']?>"placeholder="Description" class="form-control" required>
                                        </div>
                                        
                                        <div class="form-group">
                                          <label>Progress</label>
                                          <select name="Progress" class="form-control mb-3 mb-3" required>
                                            <option>Not Started</option>
                                            <option>In Progress</option>
                                            <option>Completed</option>
                                            <option>Overdue</option>
                                          </select>
                                        </div>
                                        <div class="form-group">       
                                          <label>Due Date</label>
                                          <input type="date" name="Date" placeholder="Date" class="form-control" required>
                                        </div>
                                        <div class="form-group">
                                          <label>Version</label>
                                          <input type="text" name="Version" value="<?php echo $row['Versions']?>"placeholder="Version" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                      <button type="button" data-dismiss="modal" class="btn btn-secondary">Close</button>
                                      <button type="submit" name ="update"class="btn btn-primary">Save changes</button>
                                    </div>
                                    </form>
                                  </div>
                                  </div>
                                </div>
                                  

                                <?php
                            }
                          }
                        ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
<?php
include('footer.php');
?>