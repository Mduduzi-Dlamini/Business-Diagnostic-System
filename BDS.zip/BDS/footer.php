<footer class="footer">
          <div class="footer__block block no-margin-bottom">
            <div class="container-fluid text-center">
              <!-- Please do not remove the backlink to us unless you support us at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
               <p class="no-margin-bottom">2022 &copy; Grey Cloud Technology <a target="_blank" href="https://greycloud.co.za">Grey Cloud Technology</a>.</p>
            </div>
          </div>
        </footer>
      </div>
    </div>
    <!-- JavaScript files-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="js/charts-home.js"></script>
   <!-- <script src="js/charts-custom.js"></script>-->
   
    

    <script src="js/front.js"></script>
    <?php
             $sql = "SELECT * FROM Human_Resource WHERE Progress='Not Started';";
             $result = mysqli_query($conn, $sql);
             $ns = mysqli_num_rows($result);
             
             $sql1 = "SELECT * FROM Human_Resource WHERE Progress='In Progress';";
             $result1 = mysqli_query($conn, $sql1);
             $ip = mysqli_num_rows($result1);
             
             $sql2 = "SELECT * FROM Human_Resource WHERE Progress='Completed';";
             $result2 = mysqli_query($conn, $sql2);
             $c = mysqli_num_rows($result2);
             
             $sql3 = "SELECT * FROM Human_Resource WHERE Progress='Overdue';";
             $result3 = mysqli_query($conn, $sql3);
             $od = mysqli_num_rows($result3);

    ?>
    <script>
      var PIECHARTEXMPLE    = $('#pieChartCustom1');
      var pieChartExample = new Chart(PIECHARTEXMPLE, {
          type: 'pie',
          options: {
              legend: {
                  display: true,
                  position: "left"
              }
          },
          data: {
              labels: [
                  "Not Started",
                  "In Progress",
                  "Completed",
                  "Over Due"
              ],
              
              
              datasets: [
                  {
                    
                      <?php echo "data: [".$ns.", ".$ip.", ".$c.", ".$od."]"; ?>,
                      borderWidth: 0,
                      backgroundColor: [
                          '#723ac3',
                          "#864DD9",
                          "#9762e6",
                          "#a678eb"
                      ],
                      hoverBackgroundColor: [
                          '#723ac3',
                          "#864DD9",
                          "#9762e6",
                          "#a678eb"
                      ]
                  }]
              }
      });

      var pieChartExample = {
          responsive: true
      };
    </script>
    <?php
             $seven = date('Y-m-d', strtotime('+7 days'));
             $today0 = date('Y-m-d');
             $sql1 = "SELECT * FROM Tech WHERE Renewal_date BETWEEN '$today0' AND '$seven';";
             $result = mysqli_query($conn, $sql1);
             $resultcheck = mysqli_num_rows($result);
             
             $f = date('Y-m-d', strtotime('+14 days'));
             $today2 = date('Y-m-d');
             $sql2 = "SELECT * FROM Tech WHERE Renewal_date BETWEEN '$today2' AND '$f';";
             $result1 = mysqli_query($conn, $sql2);
             $resultcheck1 = mysqli_num_rows($result1);
             
             $t = date('Y-m-d', strtotime('+30 days'));
             $today1 = date('Y-m-d');
             $sql3 = "SELECT * FROM Tech WHERE Renewal_date BETWEEN '$today1' AND '$t';";
             $result2 = mysqli_query($conn, $sql3);
             $resultcheck2 = mysqli_num_rows($result2);
             
             $today = date('Y-m-d');
            $lmonths = date('Y-m-d', strtotime('-90 days'));
            $sql = "SELECT * FROM Tech WHERE Renewal_date BETWEEN '$lmonths' AND '$today';";
             $result3 = mysqli_query($conn, $sql);
             $resultcheck3 = mysqli_num_rows($result3);

    ?>
    <script>
      var PIECHARTEXMPLE    = $('#pieChartCustom2');
      var pieChartExample = new Chart(PIECHARTEXMPLE, {
          type: 'pie',
          options: {
              legend: {
                  display: true,
                  position: "left"
              }
          },
          data: {
              labels: [
                  "7 Days",
                  "14 Days",
                  "30 Days",
                  "Expired"
              ],
              
              
              datasets: [
                  {
                    
                      <?php echo "data: [".$resultcheck.", ".$resultcheck1.", ".$resultcheck2.", ".$resultcheck3."]"; ?>,
                      borderWidth: 0,
                      backgroundColor: [
                          '#723ac3',
                          "#864DD9",
                          "#9762e6",
                          "#a678eb"
                      ],
                      hoverBackgroundColor: [
                          '#723ac3',
                          "#864DD9",
                          "#9762e6",
                          "#a678eb"
                      ]
                  }]
              }
      });

      var pieChartExample = {
          responsive: true
      };
    </script>
    <?php
             $sql = "SELECT * FROM Communication WHERE Progress='Not Started';";
             $result = mysqli_query($conn, $sql);
             $ns = mysqli_num_rows($result);
             
             $sql1 = "SELECT * FROM Communication WHERE Progress='In Progress';";
             $result1 = mysqli_query($conn, $sql1);
             $ip = mysqli_num_rows($result1);
             
             $sql2 = "SELECT * FROM Communication WHERE Progress='Completed';";
             $result2 = mysqli_query($conn, $sql2);
             $c = mysqli_num_rows($result2);
             
             $sql3 = "SELECT * FROM Communication WHERE Progress='Overdue';";
             $result3 = mysqli_query($conn, $sql3);
             $od = mysqli_num_rows($result3);

    ?>
    <script>
      var PIECHARTEXMPLE    = $('#pieChartCustom3');
      var pieChartExample = new Chart(PIECHARTEXMPLE, {
          type: 'pie',
          options: {
              legend: {
                  display: true,
                  position: "left"
              }
          },
          data: {
              labels: [
                  "Not Started",
                  "In Progress",
                  "Completed",
                  "Over Due"
              ],
              
              
              datasets: [
                  {
                    
                      <?php echo "data: [".$ns.", ".$ip.", ".$c.", ".$od."]"; ?>,
                      borderWidth: 0,
                      backgroundColor: [
                          '#723ac3',
                          "#864DD9",
                          "#9762e6",
                          "#a678eb"
                      ],
                      hoverBackgroundColor: [
                          '#723ac3',
                          "#864DD9",
                          "#9762e6",
                          "#a678eb"
                      ]
                  }]
              }
      });

      var pieChartExample = {
          responsive: true
      };
    </script>
        <?php
             $sql = "SELECT * FROM Marketing WHERE Progress='Not Started';";
             $result = mysqli_query($conn, $sql);
             $ns = mysqli_num_rows($result);
             
             $sql1 = "SELECT * FROM Marketing WHERE Progress='In Progress';";
             $result1 = mysqli_query($conn, $sql1);
             $ip = mysqli_num_rows($result1);
             
             $sql2 = "SELECT * FROM Marketing WHERE Progress='Completed';";
             $result2 = mysqli_query($conn, $sql2);
             $c = mysqli_num_rows($result2);
             
             $sql3 = "SELECT * FROM Marketing WHERE Progress='Overdue';";
             $result3 = mysqli_query($conn, $sql3);
             $od = mysqli_num_rows($result3);

    ?>
    <script>
      var PIECHARTEXMPLE    = $('#pieChartCustom4');
      var pieChartExample = new Chart(PIECHARTEXMPLE, {
          type: 'pie',
          options: {
              legend: {
                  display: true,
                  position: "left"
              }
          },
          data: {
              labels: [
                  "Not Started",
                  "In Progress",
                  "Completed",
                  "Over Due"
              ],
              
              
              datasets: [
                  {
                    
                      <?php echo "data: [".$ns.", ".$ip.", ".$c.", ".$od."]"; ?>,
                      borderWidth: 0,
                      backgroundColor: [
                          '#723ac3',
                          "#864DD9",
                          "#9762e6",
                          "#a678eb"
                      ],
                      hoverBackgroundColor: [
                          '#723ac3',
                          "#864DD9",
                          "#9762e6",
                          "#a678eb"
                      ]
                  }]
              }
      });

      var pieChartExample = {
          responsive: true
      };
    </script>
            <?php
             $sql = "SELECT * FROM Operate WHERE Progress='Not Started';";
             $result = mysqli_query($conn, $sql);
             $ns = mysqli_num_rows($result);
             
             $sql1 = "SELECT * FROM Operate WHERE Progress='In Progress';";
             $result1 = mysqli_query($conn, $sql1);
             $ip = mysqli_num_rows($result1);
             
             $sql2 = "SELECT * FROM Operate WHERE Progress='Completed';";
             $result2 = mysqli_query($conn, $sql2);
             $c = mysqli_num_rows($result2);
             
             $sql3 = "SELECT * FROM Operate WHERE Progress='Overdue';";
             $result3 = mysqli_query($conn, $sql3);
             $od = mysqli_num_rows($result3);

    ?>
    <script>
      var PIECHARTEXMPLE    = $('#pieChartCustom5');
      var pieChartExample = new Chart(PIECHARTEXMPLE, {
          type: 'pie',
          options: {
              legend: {
                  display: true,
                  position: "left"
              }
          },
          data: {
              labels: [
                  "Not Started",
                  "In Progress",
                  "Completed",
                  "Over Due"
              ],
              
              
              datasets: [
                  {
                    
                      <?php echo "data: [".$ns.", ".$ip.", ".$c.", ".$od."]"; ?>,
                      borderWidth: 0,
                      backgroundColor: [
                          '#723ac3',
                          "#864DD9",
                          "#9762e6",
                          "#a678eb"
                      ],
                      hoverBackgroundColor: [
                          '#723ac3',
                          "#864DD9",
                          "#9762e6",
                          "#a678eb"
                      ]
                  }]
              }
      });

      var pieChartExample = {
          responsive: true
      };
    </script>
  </body>
</html>