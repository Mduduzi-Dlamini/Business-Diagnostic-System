<?php
include('header.php');


if (isset($_POST['add'])) {
    $description = $_POST['description'];
    $sql = "INSERT INTO Executive(ex_id, Descriptions) VALUES (NULL,'$description');";
    mysqli_query($conn, $sql);
    echo "<script>alert(\"Successfully Added...!\")</script>";
}
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $description = $_POST['description'];
    $date = $_POST['date'];
    $comment = $_POST['comment'];
    $sql = "UPDATE Executive SET Descriptions='$description',Dates='$date',Comment='$comment' WHERE ex_id='$id';";
    mysqli_query($conn, $sql);
    echo "<script>alert(\"Successfully Added...!\")</script>";
}


?>
      <!-- Sidebar Navigation end-->
      <div class="page-content">
        <!-- Page Header-->
        <div class="page-header no-margin-bottom">
          <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">Chief Executive Officer</h2>
          </div>
        </div>
        <!-- Breadcrumb-->
        <div class="container-fluid">
          <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item active">Chief Executive Officer</li>
          </ul>
        </div>
        <section class="no-padding-top">
          <div class="container-fluid">
            <div class="row">
        
              <!-- Modal Form-->
              <div class="col-lg-6">
                <div class="block">
                  <div class="title"><strong>Add Business Examination</strong></div>
                  <div class="block-body text-center">
                    <button type="button" data-toggle="modal" data-target="#myModal" class="btn btn-primary">Add </button>
                    <!-- Modal-->
                    <div id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
                      <div role="document" class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header"><strong id="exampleModalLabel" class="modal-title">Business Examination</strong>
                            <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
                          </div>
                          <div class="modal-body">
                            <p>Add Any Business Aspect.</p>
                            <form action="ceo_diagnosis.php" method="post">
                              <div class="form-group">
                                <label>Description</label>
                                <input type="text" name="description" placeholder="Description" class="form-control" require>
                              </div>
                              
                          </div>
                          <div class="modal-footer">
                            <button type="button" data-dismiss="modal" class="btn btn-secondary">Close</button>
                            <button type="submit" name="add" class="btn btn-primary">Save changes</button>
                          </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-12">
                <div class="block">
                  <div class="title"><strong>Executive Overall Examination</strong></div>
                  <div class="table-responsive"> 
                    <table class="table table-striped table-hover">
                      <thead>
                        <tr>
                          <th>Description</th>
                          <th>Date</th>
                          <th>Comment</th>
                          <th>Update</th>
                          <th>Delete</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                        $sql = "SELECT * FROM Executive;";
                        $result = mysqli_query($conn, $sql);
                        $resultcheck = mysqli_num_rows($result);
                                  
                        if($resultcheck>0) {
                            while($row = mysqli_fetch_assoc($result)) {
                                echo '
                                <tr>
                                    <th scope="row">'.$row['Descriptions'].'</th>
                                    <td>'.$row['Dates'].'</td>
                                    <td>'.$row['Comment'].'</td>
                                    <td><button type="button" data-toggle="modal" data-target="#myModal'.$row['ex_id'].'" class="btn btn-primary">Edit</button></td>
                                    <td><button type="submit" name="add" class="btn btn-danger">Remove</button></td>
                                </tr>
                                
                                
                                ';?>
                                <div id="myModal<?php echo $row['ex_id']?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
                                    <div role="document" class="modal-dialog">
                                        <div class="modal-content">
                                        <div class="modal-header"><strong id="exampleModalLabel" class="modal-title">Business Examination</strong>
                                            <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
                                        </div>
                                        <div class="modal-body">
                                            <p>Add Any Business Aspect.</p>
                                            <form action="ceo_diagnosis.php" method="post">
                                            <input type="hidden" name="id" value="<?php echo $row['ex_id']?>">

                                            <div class="form-group">
                                                <label>Description</label>
                                                <input type="text" name="description" value="<?php echo $row['Descriptions']?>" placeholder="Description" class="form-control" required>
                                            </div>
                                            <div class="form-group">       
                                                <label>Date</label>
                                                <input type="date" name="date" value="<?php echo $row['Dates']?>" placeholder="Date" class="form-control" required>
                                            </div>
                                            <div class="form-group">
                                                <label>Comments</label>
                                                <textarea placeholder="<?php echo $row['Comment']?>" name="comment" class="form-control" required></textarea>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" data-dismiss="modal" class="btn btn-secondary">Close</button>
                                            <button type="submit" name="update" class="btn btn-primary">Update</button>
                                        </div>
                                        </form>
                                        </div>
                                    </div>
                                </div>



                                <?php
                            
                            }
                        }


                        ?>
                        
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
<?php
include('footer.php');
?>