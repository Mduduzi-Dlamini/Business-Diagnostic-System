<?php
include('header.php');

if (isset($_POST['add'])) {
    $requirements = $_POST['requirements'];
    $sql="INSERT INTO Tech(tech_id, Requirements) VALUES (NULL,'$requirements');";
    mysqli_query($conn, $sql);
    echo "<script>alert(\"Successfully Added...!\")</script>";
}
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $requirements=$_POST['Requirements'];
    $vendor = $_POST['Vendor'];
    $version = $_POST['Version'];
    $date = $_POST['Renewal_date'];
    $sql = "UPDATE Tech SET Requirements='$requirements',Vendor='$vendor',Versions='$version',Renewal_date='$date' WHERE tech_id='$id';";
    mysqli_query($conn, $sql);
    echo "<script>alert(\"Successfully Added...!\")</script>";
  }

?>
      <!-- Sidebar Navigation end-->
      <div class="page-content">
        <!-- Page Header-->
        <div class="page-header no-margin-bottom">
          <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">Technology Officer</h2>
          </div>
        </div>
        <!-- Breadcrumb-->
        <div class="container-fluid">
          <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item active">Technology Officer</li>
          </ul>
        </div>
        <section class="no-padding-top">
          <div class="container-fluid">
            <div class="row">
        
              <!-- Modal Form-->
              <div class="col-lg-6">
                <div class="block">
                  <div class="title"><strong>Add Tech Business Examination</strong></div>
                  <div class="block-body text-center">
                    <button type="button" data-toggle="modal" data-target="#myModal" class="btn btn-primary">Add </button>
                    <!-- Modal-->
                    <div id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
                      <div role="document" class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header"><strong id="exampleModalLabel" class="modal-title">Business Examination</strong>
                            <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
                          </div>
                          <div class="modal-body">
                            <p>Add Any Tech Business Aspect.</p>
                            <form action="tech_diagnosis.php" method="post">
                              <div class="form-group">
                                <label>Requirements</label>
                                <input type="text" name="requirements" placeholder="Requirements" class="form-control">
                              </div>
                              
                          <div class="modal-footer">
                            <button type="button" data-dismiss="modal" class="btn btn-secondary">Close</button>
                            <button type="submit" name="add" class="btn btn-primary">Save changes</button>
                          </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
            </div>
            <div class="col-lg-12">
                <div class="block">
                  <div class="title"><strong>Striped table with hover effect</strong></div>
                  <div class="table-responsive"> 
                    <table class="table table-striped table-hover">
                      <thead>
                        <tr>
                          <th>Requirements</th>
                          <th>Vendor</th>
                          <th>Version</th>
                          <th>Renewal_date</th>
                          <th>Adit</th>
                          <th>Remove</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php
                        $sql = "SELECT * FROM Tech;";
                        $result = mysqli_query($conn, $sql);
                        $resultcheck = mysqli_num_rows($result);
                                  
                        if($resultcheck>0) {
                            while($row = mysqli_fetch_assoc($result)) {
                                echo '
                                <tr>
                                    <th scope="row">'.$row['Requirements'].'</th>
                                    <td>'.$row['Vendor'].'</td>
                                    <td>'.$row['Versions'].'</td>
                                    <td>'.$row['Renewal_date'].'</td>
                                    <td><button type="button" data-toggle="modal" data-target="#myModal'.$row['tech_id'].'" class="btn btn-primary">Edit</button></td>
                                    <td><button type="submit" name="add" class="btn btn-danger">Remove</button></td>
                                </tr>
                                
                                
                                ';?>
                                <div id="myModal<?php echo $row['tech_id']?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
                                    <div role="document" class="modal-dialog">
                                        <div class="modal-content">
                                        <div class="modal-header"><strong id="exampleModalLabel" class="modal-title">Business Examination</strong>
                                            <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
                                        </div>
                                        <div class="modal-body">
                                            <p>Add Any Business Aspect.</p>
                                            <form action="ceo_diagnosis.php" method="post">
                                            <input type="hidden" name="id" value="<?php echo $row['tech_id']?>">
                                            <div class="form-group">
                                                <label>Requirements</label>
                                                <input type="text" name="Requirements" value="<?php echo $row['Requirements']?>" placeholder="Requirements" class="form-control" required>
                                            </div>
                                            <div class="form-group">
                                                <label>Vendor</label>
                                                <input type="text" name="Vendor" value="<?php echo $row['Vendor']?>" placeholder="Vendor" class="form-control" required>
                                            </div>
                                            <div class="form-group">
                                                <label>Version</label>
                                                <input type="text" name="Version" value="<?php echo $row['Versions']?>" placeholder="Version" class="form-control" required>
                                            </div>
                                            <div class="form-group">       
                                                <label>Renewal_date</label>
                                                <input type="date" name="Renewal_date" value="<?php echo $row['Renewal_date']?>" placeholder="Renewal_date" class="form-control" required>
                                            </div>
                                            
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" data-dismiss="modal" class="btn btn-secondary">Close</button>
                                            <button type="submit" name="update" class="btn btn-primary">Update</button>
                                        </div>
                                        </form>
                                        </div>
                                    </div>
                                </div>


                                <?php
                            }
                        }


                        ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
          </div>
        </section>
<?php
include('footer.php');
?>