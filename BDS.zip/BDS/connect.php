<?php
	$user = 'root';
	$pass = '';
	$db = 'BDS_db';
	$conn = new mysqli('localhost', $user, $pass,$db)or die("Unable to connect");
?>