<?php
include('header.php');
if (isset($_POST['add'])) {
  $check=$_POST['Checklist'];
  $sql="INSERT INTO Finance (fin_id, Checklist) VALUES (NULL,'$check');";
  mysqli_query($conn, $sql);
  echo("<script>alert(\"Successfully Added...!\")</script>");
}
if (isset($_POST['update'])) {
  $id = $_POST['id'];
  $check=$_POST['Checklist'];
  $description=$_POST['Description'];
  $type = $_POST['Type'];
  $comment = $_POST['Comment'];
  $sql = "UPDATE Finance SET Checklist='$check',Descriptions='$description',Types='$type',Comment='$comment' WHERE fin_id='$id';";
  mysqli_query($conn, $sql);
  echo "<script>alert(\"Successfully Added...!\")</script>";
}
?>
      <!-- Sidebar Navigation end-->
      <div class="page-content">
        <!-- Page Header-->
        <div class="page-header no-margin-bottom">
          <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">Finance Officer</h2>
          </div>
        </div>
        <!-- Breadcrumb-->
        <div class="container-fluid">
          <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item active">Finance Officer</li>
          </ul>
        </div>
        <section class="no-padding-top">
          <div class="container-fluid">
            <div class="row">
        
              <!-- Modal Form-->
              <div class="col-lg-6">
                <div class="block">
                  <div class="title"><strong>Add Finance Business Examination</strong></div>
                  <div class="block-body text-center">
                    <button type="button" data-toggle="modal" data-target="#myModal" class="btn btn-primary">Add </button>
                    <!-- Modal-->
                    <div id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
                      <div role="document" class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header"><strong id="exampleModalLabel" class="modal-title">Business Examination</strong>
                            <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
                          </div>
                          <div class="modal-body">
                            <p>Add Any Finance Business Aspect.</p>
                            <form action="fin_diagnosis.php" method="post">
                              <div class="form-group">
                                <label>Checklist</label>
                                <input type="text" name="Checklist" placeholder="Checklist" class="form-control">
                              </div>
                              
                          </div>
                          <div class="modal-footer">
                            <button type="button" data-dismiss="modal" class="btn btn-secondary">Close</button>
                            <button type="submit" name="add"class="btn btn-primary">Save changes</button>
                          </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-12">
                <div class="block">
                  <div class="title"><strong>Striped table with hover effect</strong></div>
                  <div class="table-responsive"> 
                    <table class="table table-striped table-hover">
                      <thead>
                        <tr>
                          <th>Checklist</th>
                          <th>Description</th>
                          <th>Type</th>
                          <th>Comment</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php
                        $sql = "SELECT * FROM Finance;";
                        $result = mysqli_query($conn, $sql);
                        $resultcheck = mysqli_num_rows($result);
                                  
                        if($resultcheck>0) {
                            while($row = mysqli_fetch_assoc($result)) {
                                echo '
                                <tr>
                                    <th scope="row">'.$row['Checklist'].'</th>
                                    <td>'.$row['Descriptions'].'</td>
                                    <td>'.$row['Types'].'</td>
                                    <td>'.$row['Comment'].'</td>
                                    <td><button type="button" data-toggle="modal" data-target="#myModal'.$row['fin_id'].'" class="btn btn-primary">Edit</button></td>
                                    <td><button type="submit" name="add" class="btn btn-danger">Remove</button></td>
                                </tr>
                                
                                
                                ';?>

                                  <div id="myModal<?php echo $row['fin_id'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
                                    <div role="document" class="modal-dialog">
                                      <div class="modal-content">
                                        <div class="modal-header"><strong id="exampleModalLabel" class="modal-title">Business Examination</strong>
                                          <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
                                        </div>
                                        <div class="modal-body">
                                          <p>Add Any Finance Business Aspect.</p>
                                          <form action="fin_diagnosis.php" method="post">
                                            <input type="hidden" name="id" value="<?php echo $row['fin_id']?>">
                                            <div class="form-group">
                                              <label>Checklist</label>
                                              <input type="text" name="Checklist" value="<?php echo $row['Checklist'] ?>" placeholder="<?php echo $row['Checklist'] ?>" class="form-control">
                                            </div>
                                            <div class="form-group">
                                              <label>Description</label>
                                              <input type="text" placeholder="Description" name="Description"class="form-control">
                                            </div>
                                            
                                            <div class="form-group">
                                              <label>Type</label>
                                              <input type="text" placeholder="Type"name="Type" class="form-control">
                                            </div>
                                            <div class="form-group">
                                              <label>Comments</label>
                                              <textarea placeholder="comments" name="Comment"class="form-control"></textarea>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                          <button type="button" data-dismiss="modal" class="btn btn-secondary">Close</button>
                                          <button type="submit" name="update" class="btn btn-primary">Save changes</button>
                                        </div>
                                        </form>
                                      </div>
                                    </div>
                                  </div>
                                  <?php
                            }
                        }
                        ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
<?php
include('footer.php');
?>