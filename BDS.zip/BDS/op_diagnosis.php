<?php
include('header.php');

if (isset($_POST['add'])) {
  $op=$_POST['op'];
  $sql="INSERT INTO Operate (op_id, Operation) VALUES (NULL,'$op');";
  mysqli_query($conn, $sql);
  echo("<script>alert(\"Successfully Added...!\")</script>");

}
if (isset($_POST['update'])) {

  $id= $_POST['id'];
  $Operation=$_POST['Operation'];
  $Descriptions = $_POST['Descriptions'];
  $Versions_or_Licences = $_POST['Versions_or_Licences'];
  $Completion_Date=$_POST['Completion_Date'];
  $Review_Date = $_POST['Review_Date'];
  $sql="UPDATE Operate SET Operation='$Operation',Descriptions='$Descriptions',Versions_or_Licences='$Versions_or_Licences',Completion_Date='$Completion_Date',Review_Date='$Review_Date' WHERE op_id='$id';";
  mysqli_query($conn, $sql);
  echo "<script>alert(\"Successfully Added...!\")</script>";
}
?>
      <!-- Sidebar Navigation end-->
      <div class="page-content">
        <!-- Page Header-->
        <div class="page-header no-margin-bottom">
          <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">Operations Officer</h2>
          </div>
        </div>
        <!-- Breadcrumb-->
        <div class="container-fluid">
          <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item active">Operations Officer</li>
          </ul>
        </div>
        <section class="no-padding-top">
          <div class="container-fluid">
            <div class="row">
        
              <!-- Modal Form-->
              <div class="col-lg-6">
                <div class="block">
                  <div class="title"><strong>Add Operations Business Examination</strong></div>
                  <div class="block-body text-center">
                    <button type="button" data-toggle="modal" data-target="#myModal" class="btn btn-primary">Add </button>
                    <!-- Modal-->
                    <div id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
                      <div role="document" class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header"><strong id="exampleModalLabel" class="modal-title">Business Examination</strong>
                            <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
                          </div>
                          <div class="modal-body">
                            <p>Add Any Operations Business Aspect.</p>
                            <form action="op_diagnosis.php" method="post">
                              
                              <div class="form-group">
                                <label>Operations Excellence</label>
                                <input type="text" name="op" placeholder="Operations Excellence" class="form-control">
                              </div>
                          </div>
                          <div class="modal-footer">
                            <button type="button" data-dismiss="modal" class="btn btn-secondary">Close</button>
                            <button type="submit" name="add" class="btn btn-primary">Save changes</button>
                          </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-12">
                <div class="block">
                  <div class="title"><strong>Striped table with hover effect</strong></div>
                  <div class="table-responsive"> 
                    <table class="table table-striped table-hover">
                      <thead>
                        <tr>
                          <th>Operation</th>
                          <th>Descriptions</th>
                          <th>Versions_or_Licences</th>
                          <th>Progress</th>
                          <th>Completion_Date</th>
                          <th>Review_Date</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php
                        $sql = "SELECT * FROM Operate;";
                        $result = mysqli_query($conn, $sql);
                        $resultcheck = mysqli_num_rows($result);
                                  
                        if($resultcheck>0) {
                            while($row = mysqli_fetch_assoc($result)) {
                                echo '
                                
                                <tr>
                                    <th scope="row">'.$row['Operation'].'</th>
                                    <td>'.$row['Descriptions'].'</td>
                                    <td>'.$row['Versions_or_Licences'].'</td>
                                    <td>'.$row['Progress'].'</td>
                                    <td>'.$row['Completion_Date'].'</td>
                                    <td>'.$row['Review_Date'].'</td>
                                    <td><button type="button" data-toggle="modal" data-target="#myModal'.$row['op_id'].'" class="btn btn-primary">Edit</button></td>
                                    <td><button type="submit" name="add" class="btn btn-danger">Remove</button></td>
                                </tr>
                                
                                
                                ';?>


                                  <div id="myModal<?php echo $row['op_id'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
                                    <div role="document" class="modal-dialog">
                                      <div class="modal-content">
                                        <div class="modal-header"><strong id="exampleModalLabel" class="modal-title">Business Examination</strong>
                                          <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
                                        </div>
                                        <div class="modal-body">
                                          <p>Add Any Operations Business Aspect.</p>
                                          <form action="op_diagnosis.php" method="post">
                                          <input type="hidden" name="id" value="<?php echo $row['op_id'] ?>">
                                            <div class="form-group">
                                              <label>Operations Excellence</label>
                                              <input type="text" name="Operation" value="<?php echo $row['Operation'] ?>" placeholder="Operations Excellence" class="form-control">
                                            </div>
                                            <div class="form-group">
                                              <label>Description</label>
                                              <input type="text" name="Descriptions" placeholder="Description" class="form-control">
                                            </div>
                                            <div class="form-group">
                                              <label>Version Number/Number of Licenses</label>
                                              <input type="text" name="Versions_or_Licences" placeholder="Version Number/Number of Licenses" class="form-control">
                                            </div>
                                            
                                            <div class="form-group">
                                              <label>Progress</label>
                                              <label>Progress</label>
                                              <select name="Progress" class="form-control mb-3 mb-3" required>
                                                <option>Not Started</option>
                                                <option>In Progress</option>
                                                <option>Completed</option>
                                                <option>Overdue</option>
                                              </select>
                                            </div>
                                            <div class="form-group">       
                                              <label>Completion Date</label>
                                              <input type="date" name="Completion_Date" placeholder="Completion Date" class="form-control">
                                            </div>
                                            <div class="form-group">       
                                              <label>Review Date</label>
                                              <input type="date" name="Review_Date"placeholder="Review Date" class="form-control">
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                          <button type="button" data-dismiss="modal" class="btn btn-secondary">Close</button>
                                          <button type="submit" name="update" class="btn btn-primary">Save changes</button>
                                        </div>
                                        </form>
                                      </div>
                                    </div>
                                  </div>
                                  <?php
                            }
                        }
                        ?>
                        
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
<?php
include('footer.php');
?>