<?php
include('header.php');
if (isset($_POST['add'])) {
  $agreement = $_POST['agreements'];
  $sql = "INSERT INTO Communication(comm_id, Agreements) VALUES (Null,'$agreement');";
  mysqli_query($conn, $sql);
  echo "<script>alert(\"Successfully Added...!\")</script>";
}
if (isset($_POST['update'])) {
  $id= $_POST['id'];
  $agreement=$_POST['Agreements'];
  $description = $_POST['Descriptions'];
  $progress = $_POST['Progress'];
  $date=$_POST['Dates'];
  $renewal_date = $_POST['Revision_Date'];
  $comments =$_POST['Comments'];
  $sql="UPDATE Communication SET Agreements='$agreement',Descriptions='$description',Progress='$progress',Dates='$date',Revision_Date='$renewal_date',Comments='$comments' WHERE comm_id='$id';";
  mysqli_query($conn, $sql);
  echo "<script>alert(\"Successfully Added...!\")</script>";
}
?>
      <!-- Sidebar Navigation end-->
      <div class="page-content">
        <!-- Page Header-->
        <div class="page-header no-margin-bottom">
          <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">Communications Officer</h2>
          </div>
        </div>
        <!-- Breadcrumb-->
        <div class="container-fluid">
          <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item active">Communications Officer</li>
          </ul>
        </div>
        <section class="no-padding-top">
          <div class="container-fluid">
            <div class="row">
        
              <!-- Modal Form-->
              <div class="col-lg-6">
                <div class="block">
                  <div class="title"><strong>Add Communications Business Examination</strong></div>
                  <div class="block-body text-center">
                    <button type="button" data-toggle="modal" data-target="#myModal" class="btn btn-primary">Add </button>
                    <!-- Modal-->
                    <div id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
                      <div role="document" class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header"><strong id="exampleModalLabel" class="modal-title">Business Examination</strong>
                            <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
                          </div>
                          <div class="modal-body">
                            <p>Add Any Communications Business Aspect.</p>
                            <form action="com_diagnosis.php" method="post">
                              <div class="form-group">
                                <label>Agreements</label>
                                <input type="text" name="agreements" placeholder="Agreements" class="form-control">
                              </div>
                              
                          </div>
                          <div class="modal-footer">
                            <button type="button" data-dismiss="modal" class="btn btn-secondary">Close</button>
                            <button type="submit" name="add" class="btn btn-primary">Save changes</button>
                          </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-12">
                <div class="block">
                  <div class="title"><strong>Striped table with hover effect</strong></div>
                  <div class="table-responsive"> 
                    <table class="table table-striped table-hover">
                      <thead>
                        <tr>
                          <th>Agreements</th>
                          <th>Description</th>
                          <th>Progress</th>
                          <th>Date</th>
                          <th>Revision Date</th>
                          <th>Comments</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php
                        $sql = "SELECT * FROM Communication;";
                        $result = mysqli_query($conn, $sql);
                        $resultcheck = mysqli_num_rows($result);
                                  
                        if($resultcheck>0) {
                            while($row = mysqli_fetch_assoc($result)) {
                                echo '
                                <tr>
                                    <th scope="row">'.$row['Agreements'].'</th>
                                    <td>'.$row['Descriptions'].'</td>
                                    <td>'.$row['Progress'].'</td>
                                    <td>'.$row['Dates'].'</td>
                                    <td>'.$row['Revision_Date'].'</td>
                                    <td>'.$row['Comments'].'</td>
                                    
                                    <td><button type="button" data-toggle="modal" data-target="#myModal'.$row['comm_id'].'" class="btn btn-primary">Edit</button></td>
                                    <td><button type="submit" name="add" class="btn btn-danger">Remove</button></td>
                                </tr>
                                
                                
                                ';?>
                                <div id="myModal<?php echo $row['comm_id'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
                                  <div role="document" class="modal-dialog">
                                    <div class="modal-content">
                                      <div class="modal-header"><strong id="exampleModalLabel" class="modal-title">Business Examination</strong>
                                        <button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
                                      </div>
                                      <div class="modal-body">
                                        <p>Add Any Communications Business Aspect.</p>
                                        <form action="com_diagnosis.php" method="post">
                                          <input type="hidden"name="id" value="<?php echo $row['comm_id'] ?>">
                                          <div class="form-group">
                                            <label>Agreements</label>
                                            <input type="text" name ="Agreements"value="<?php echo $row['Agreements'] ?>" placeholder="Agreements" class="form-control">
                                          </div>
                                          <div class="form-group">
                                            <label>Description</label>
                                            <input type="text" name="Descriptions" placeholder="Description" class="form-control">
                                          </div>
                                          
                                          <div class="form-group">
                                            <label>Progress</label>
                                            <select name="Progress" class="form-control mb-3 mb-3" required>
                                              <option>Not Started</option>
                                              <option>In Progress</option>
                                              <option>Completed</option>
                                              <option>Overdue</option>
                                            </select>
                                          </div>
                                          <div class="form-group">       
                                            <label>Date</label>
                                            <input type="date" name="Dates" placeholder="Date" class="form-control">
                                          </div>
                                          <div class="form-group">       
                                            <label>Revision Date</label>
                                            <input type="date" name="Revision_Date" placeholder="Revision Date" class="form-control">
                                          </div>
                                          <div class="form-group">
                                            <label>Comments</label>
                                            <textarea placeholder="comments" name="Comments"class="form-control"></textarea>
                                          </div>
                                      </div>
                                      <div class="modal-footer">
                                        <button type="button" data-dismiss="modal" class="btn btn-secondary">Close</button>
                                        <button type="submit" name ="update"class="btn btn-primary">Save changes</button>
                                      </div>
                                      </form>
                                    </div>
                                  </div>
                                </div>
                            <?php
                            }
                        }
                        ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
<?php
include('footer.php');
?>